# حسبة — Android

هذه النسخة تعتمد تصميم حسبة كمرجع نهائي، مع أسماء لاعبين قابلة للتعديل وأيقونة تطبيق بنفس الثيم.

## تجهيز المشروع
```bash
flutter create .
flutter pub get
dart run flutter_launcher_icons
```

اسم التطبيق للمستخدم هو **حسبة**، والأيقونة مأخوذة من هوية حسبة الداكنة/الذهبية.

## إخراج APK
```bash
flutter build apk --release
```

الملف الناتج يكون عادة داخل:
`build/app/outputs/flutter-apk/app-release.apk`

## Play Store
```bash
flutter build appbundle --release
```
